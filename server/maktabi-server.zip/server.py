# -*- coding: utf-8 -*-
"""مكتبي — اللوحة الشخصية لوكيل النيابة (نسخة الكمبيوتر / الفلاشة).

- بيشتغل على الجهاز ده بس (127.0.0.1) — مش مفتوح على الشبكة.
- كل البيانات متشفرة بكلمة السر في ملف واحد data/vault.bin (من غير أي مكتبات إضافية).
- لو نسيت كلمة السر البيانات مش هتتفتح — مفيش باب خلفي.
- مبني على لوحة عرض التوزيع والإنجاز (الإصدار ٨) بنفس الكشوف وطريقة الـPDF و Word و Excel.
"""
from __future__ import annotations
import sys
from pathlib import Path as _P
_LIBS = _P(__file__).resolve().parent / 'pylibs'
if _LIBS.is_dir() and str(_LIBS) not in sys.path:
    sys.path.insert(0, str(_LIBS))

import base64
import datetime as dt
import hashlib
import hmac
import io
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import subprocess
import tempfile
import threading
import time
import urllib.request
import urllib.error
import zlib
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, quote

APP_VERSION = '1.0'
BASE = Path(__file__).resolve().parent
DATA_DIR = BASE / 'data'
BACKUP_DIR = DATA_DIR / 'backups'
VAULT = DATA_DIR / 'vault.bin'
FONTS_DIR = BASE / 'fonts'
PORT = int(os.getenv('MAKTABI_PORT', '8770'))
HOST = '127.0.0.1'
# نسخة السيرفر: الدومين المسموح بيه (ورا Caddy) — والكوكي آمنة على HTTPS
EXTRA_HOSTS = [h.strip().lower() for h in os.getenv('MAKTABI_HOSTS', '').split(',') if h.strip()]
COOKIE_SEC = '; Secure' if os.getenv('MAKTABI_SECURE') else ''
SERVER_MODE = bool(EXTRA_HOSTS)
LOCK = threading.RLock()
MAX_UPLOAD = 40 * 1024 * 1024

# كل اللي في الذاكرة بعد فتح الخزنة — بيتمسح أول ما البرنامج يتقفل
KEY = None          # (enc_key, mac_key, salt, kdf-params)
STATE = None
VERSION = 0
SESSIONS = {}
LAST_ACT = 0.0
CFG = {'pdf_owner_password': ''}   # بيستخدمه encrypt_pdf من كود الإصدار ٨


def log(*a):
    try:
        print(*a, flush=True)
    except Exception:
        pass


# ───────────── التشفير (مكتبات بايثون الأساسية بس) ─────────────
# المفتاح: scrypt من كلمة السر — التشفير: BLAKE2b بمفتاح كـ keystream (CTR) — التوثيق: BLAKE2b-MAC بمفتاح منفصل
MAGIC = b'MAKTABI-VAULT-1\n'
KDF_DEFAULT = {'n': 2 ** 15, 'r': 8, 'p': 1}


def derive(password, salt, kdf):
    km = hashlib.scrypt(password.encode('utf-8'), salt=salt, n=int(kdf['n']), r=int(kdf['r']), p=int(kdf['p']),
                        maxmem=256 * 1024 * 1024, dklen=64)
    return km[:32], km[32:]


def _keystream(key, nonce, length):
    out = []
    blocks = (length + 63) // 64
    for i in range(blocks):
        out.append(hashlib.blake2b(nonce + i.to_bytes(8, 'little'), key=key, digest_size=64).digest())
    return b''.join(out)[:length]


def _xor(data, ks):
    if not data:
        return b''
    return (int.from_bytes(data, 'little') ^ int.from_bytes(ks, 'little')).to_bytes(len(data), 'little')


def seal(obj, key):
    enc, mac, salt, kdf = key
    header = json.dumps({'kdf': 'scrypt', 'n': kdf['n'], 'r': kdf['r'], 'p': kdf['p'], 'salt': salt.hex()},
                        separators=(',', ':')).encode() + b'\n'
    plain = zlib.compress(json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8'), 6)
    nonce = secrets.token_bytes(16)
    ct = _xor(plain, _keystream(enc, nonce, len(plain)))
    tag = hashlib.blake2b(MAGIC + header + nonce + ct, key=mac, digest_size=32).digest()
    return MAGIC + header + nonce + ct + tag


def read_header(raw):
    if not raw.startswith(MAGIC):
        raise ValueError('ملف البيانات مش من البرنامج ده')
    rest = raw[len(MAGIC):]
    nl = rest.index(b'\n')
    header = rest[:nl + 1]
    meta = json.loads(header)
    return header, meta, rest[nl + 1:]


def open_vault(raw, password):
    header, meta, body = read_header(raw)
    salt = bytes.fromhex(meta['salt'])
    kdf = {'n': meta['n'], 'r': meta['r'], 'p': meta['p']}
    enc, mac = derive(password, salt, kdf)
    nonce, ct, tag = body[:16], body[16:-32], body[-32:]
    good = hashlib.blake2b(MAGIC + header + nonce + ct, key=mac, digest_size=32).digest()
    if not hmac.compare_digest(tag, good):
        raise PermissionError('كلمة السر غير صحيحة')
    plain = zlib.decompress(_xor(ct, _keystream(enc, nonce, len(ct))))
    return json.loads(plain.decode('utf-8')), (enc, mac, salt, kdf)


def new_key(password):
    salt = secrets.token_bytes(16)
    kdf = dict(KDF_DEFAULT)
    enc, mac = derive(password, salt, kdf)
    return enc, mac, salt, kdf


def write_vault(obj):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    blob = seal(obj, KEY)
    tmp = VAULT.with_name(VAULT.name + '.tmp')
    with open(tmp, 'wb') as f:
        f.write(blob)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, VAULT)


def backup(tag='daily', force=False):
    """نسخة من الملف المتشفر نفسه — بتفضل متشفرة بنفس كلمة السر وقت النسخ."""
    if not VAULT.exists():
        return
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    today = dt.datetime.now().strftime('%Y-%m-%d')
    dst = BACKUP_DIR / (today + '-' + tag + '.bin')
    if dst.exists() and not force:
        return
    if dst.exists():
        dst = BACKUP_DIR / (dt.datetime.now().strftime('%Y-%m-%d_%H%M%S') + '-' + tag + '.bin')
    shutil.copy2(VAULT, dst)
    files = sorted(BACKUP_DIR.glob('*.bin'))
    for old in files[:-60]:
        try:
            old.unlink()
        except OSError:
            pass


# ───────────── البيانات ─────────────
SECRET_KEYS = ('aiKey', 'sheetPassword')


def blank_state():
    return {'schema': 1, 'createdAt': dt.datetime.now().isoformat(timespec='seconds'),
            'settings': {}, 'officers': [], 'attendance': {}, 'cases': [], 'investigations': [],
            'qbank': {}, 'caseLogs': {}, 'snooze': {}, 'imports': [], 'secrets': {}}


def public_state():
    d = dict(STATE)
    sec = d.get('secrets') or {}
    d['secrets'] = {k: bool(sec.get(k)) for k in SECRET_KEYS}
    return d


def save_state(new_data):
    global VERSION, STATE
    sec = (STATE or {}).get('secrets') or {}
    new_data['secrets'] = sec
    backup('daily')
    VERSION += 1
    STATE = new_data
    write_vault(STATE)


def lock_now():
    global KEY, STATE
    with LOCK:
        KEY = None
        STATE = None
        SESSIONS.clear()
        CFG['pdf_owner_password'] = ''


def idle_minutes():
    try:
        m = int(((STATE or {}).get('settings') or {}).get('idleLock') or 30)
    except (TypeError, ValueError):
        m = 30
    return max(0, min(m, 600))


def check_idle():
    if KEY is None:
        return
    m = idle_minutes()
    if m and time.time() - LAST_ACT > m * 60:
        log('  Locked after %d idle minutes.' % m)
        lock_now()


def make_session():
    tok = secrets.token_urlsafe(32)
    SESSIONS[tok] = time.time()
    return tok


def session_ok(request):
    if KEY is None:
        return False
    try:
        c = SimpleCookie()
        c.load(request.headers.get('Cookie', ''))
        tok = c['maktabi'].value
    except Exception:
        return False
    return tok in SESSIONS


FAILS = []


def too_many_fails():
    now = time.time()
    win = 900 if SERVER_MODE else 600
    FAILS[:] = [t for t in FAILS if now - t < win]
    return len(FAILS) >= (5 if SERVER_MODE else 10)

# ───────────── الخطوط ─────────────
FONTS_URL = ("https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700"
             "&family=Noto+Kufi+Arabic:wght@500;700&family=Aref+Ruqaa:wght@400;700"
             "&family=Reem+Kufi:wght@500;700&display=swap")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"


def cache_fonts():
    """ينزّل الخطوط مرة واحدة ويحفظها جنب السيرفر. لو مفيش نت بيعدّي بهدوء ويحاول المرة الجاية."""
    css_path = FONTS_DIR / 'fonts.css'
    if css_path.exists():
        return
    try:
        req = urllib.request.Request(FONTS_URL, headers={'User-Agent': UA})
        css = urllib.request.urlopen(req, timeout=20).read().decode('utf-8')
        urls = list(dict.fromkeys(re.findall(r"url\((https://[^)]+)\)", css)))
        if not urls:
            return
        FONTS_DIR.mkdir(parents=True, exist_ok=True)
        for i, u in enumerate(urls):
            data = urllib.request.urlopen(urllib.request.Request(u, headers={'User-Agent': UA}), timeout=40).read()
            (FONTS_DIR / ('f%03d.woff2' % i)).write_bytes(data)
            css = css.replace(u, 'f%03d.woff2' % i)
        tmp = css_path.with_suffix('.tmp')
        tmp.write_text(css, encoding='utf-8')
        os.replace(tmp, css_path)
        log('  Arabic fonts saved for offline use (%d files).' % len(urls))
    except Exception as exc:
        log('  Fonts not downloaded yet (%s). Will try again next start.' % type(exc).__name__)


def inline_fonts_css():
    """ملف الخطوط بعد ما نحط الخطوط نفسها جواه — عشان الـPDF يطلع بالخط الصح من غير نت."""
    css_path = FONTS_DIR / 'fonts.css'
    if not css_path.exists():
        return ''
    css = css_path.read_text(encoding='utf-8')

    def rep(m):
        f = FONTS_DIR / m.group(1)
        if not f.exists():
            return m.group(0)
        return 'url(data:font/woff2;base64,' + base64.b64encode(f.read_bytes()).decode() + ')'
    return re.sub(r'url\(([a-zA-Z0-9_.-]+\.woff2)\)', rep, css)


# ───────────── PDF بنفس شكل الكشف عن طريق Edge / Chrome ─────────────
def find_browser():
    cands = []
    if os.getenv('NIYABA_BROWSER'):
        cands.append(os.getenv('NIYABA_BROWSER'))
    for base in filter(None, [os.getenv('PROGRAMFILES(X86)'), os.getenv('PROGRAMFILES'), os.getenv('LOCALAPPDATA')]):
        cands += [os.path.join(base, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
                  os.path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe')]
    cands += [r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
              r'C:\Program Files\Microsoft\Edge\Application\msedge.exe',
              r'C:\Program Files\Google\Chrome\Application\chrome.exe',
              '/usr/bin/microsoft-edge', '/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser']
    for c in cands:
        if c and os.path.exists(c):
            return c
    return None


def encrypt_pdf(data):
    try:
        from pypdf import PdfReader, PdfWriter
        from pypdf.constants import UserAccessPermissions
    except ImportError:
        return data, False
    try:
        w = PdfWriter()
        w.append_pages_from_reader(PdfReader(io.BytesIO(data)))
        perms = (UserAccessPermissions.PRINT | UserAccessPermissions.PRINT_TO_REPRESENTATION)
        w.encrypt(user_password='', owner_password=CFG['pdf_owner_password'], algorithm='AES-256', permissions_flag=perms)
        out = io.BytesIO()
        w.write(out)
        return out.getvalue(), True
    except Exception as exc:
        log('  PDF protection skipped:', exc)
        return data, False


def html_to_pdf(html):
    browser = find_browser()
    if not browser:
        raise RuntimeError('مش لاقي متصفح Edge أو Chrome على الجهاز ده لعمل PDF')
    fonts = inline_fonts_css()
    if fonts:
        html = html.replace('<head>', '<head><style>' + fonts + '</style>', 1)
    with tempfile.TemporaryDirectory(prefix='niyaba-pdf-') as td:
        src = Path(td) / 'sheet.html'
        out = Path(td) / 'out.pdf'
        src.write_text(html, encoding='utf-8')
        cmd = [browser, '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
               '--disable-extensions', '--disable-sync', '--user-data-dir=' + str(Path(td) / 'profile'),
               '--no-pdf-header-footer', '--print-to-pdf-no-header', '--virtual-time-budget=6000',
               '--print-to-pdf=' + str(out), src.as_uri()]
        if os.name != 'nt':
            cmd.insert(1, '--no-sandbox')
        kw = {}
        if os.name == 'nt':
            kw['creationflags'] = 0x08000000  # من غير ما تظهر نافذة
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120, **kw)
        if not out.exists() or out.stat().st_size < 500:
            raise RuntimeError('المتصفح ما قدرش يطلع ملف PDF')
        return out.read_bytes()


# ───────────── تصدير الكشف Word / Excel (محمي من التعديل بكلمة مرور الكشوف) ─────────────
import zipfile as _zip
from xml.sax.saxutils import escape as _x

_INITIAL_CODE = [0xE1F0, 0x1D0F, 0xCC9C, 0x84C0, 0x110C, 0x0E10, 0xF1CE, 0x313E, 0x1872, 0xE139, 0xD40F, 0x84F9,
                 0x280C, 0xA96A, 0x4EC3]
_ENC_MATRIX = [
    [0xAEFC, 0x4DD9, 0x9BB2, 0x2745, 0x4E8A, 0x9D14, 0x2A09], [0x7B61, 0xF6C2, 0xFDA5, 0xEB6B, 0xC6F7, 0x9DCF, 0x2BBF],
    [0x4563, 0x8AC6, 0x05AD, 0x0B5A, 0x16B4, 0x2D68, 0x5AD0], [0x0375, 0x06EA, 0x0DD4, 0x1BA8, 0x3750, 0x6EA0, 0xDD40],
    [0xD849, 0xA0B3, 0x5147, 0xA28E, 0x553D, 0xAA7A, 0x44D5], [0x6F45, 0xDE8A, 0xAD35, 0x4A4B, 0x9496, 0x390D, 0x721A],
    [0xEB23, 0xC667, 0x9CEF, 0x29FF, 0x53FE, 0xA7FC, 0x5FD9], [0x47D3, 0x8FA6, 0x0F6D, 0x1EDA, 0x3DB4, 0x7B68, 0xF6D0],
    [0xB861, 0x60E3, 0xC1C6, 0x93AD, 0x377B, 0x6EF6, 0xDDEC], [0x45A0, 0x8B40, 0x06A1, 0x0D42, 0x1A84, 0x3508, 0x6A10],
    [0xAA51, 0x4483, 0x8906, 0x022D, 0x045A, 0x08B4, 0x1168], [0x76B4, 0xED68, 0xCAF1, 0x85C3, 0x1BA7, 0x374E, 0x6E9C],
    [0x3730, 0x6E60, 0xDCC0, 0xA9A1, 0x4363, 0x86C6, 0x1DAD], [0x3331, 0x6662, 0xCCC4, 0x89A9, 0x0373, 0x06E6, 0x0DCC],
    [0x1021, 0x2042, 0x4084, 0x8108, 0x1231, 0x2462, 0x48C4]]


def _ansi(pw):
    out = []
    for ch in pw[:15]:
        c = ord(ch)
        lo, hi = c & 0xFF, (c >> 8) & 0xFF
        out.append(lo if lo else hi)
    return out


def _xor_verifier1(pw):
    b = _ansi(pw)
    v = 0
    if b:
        for x in reversed(b):
            v = (((v >> 14) & 1) | ((v << 1) & 0x7FFF)) ^ x
        v = (((v >> 14) & 1) | ((v << 1) & 0x7FFF)) ^ len(b) ^ 0xCE4B
    return v & 0xFFFF


def _xor_verifier2(pw):
    b = _ansi(pw)
    if not b:
        return 0
    high = _INITIAL_CODE[len(b) - 1]
    for i, ch in enumerate(b):
        row = 15 - len(b) + i
        for bit in range(7):
            if ch & (1 << bit):
                high ^= _ENC_MATRIX[row][bit]
    return (_xor_verifier1(pw) & 0xFFFF) | (high << 16)


def word_protection_xml(pw):
    """حماية «للقراءة فقط» في Word بكلمة مرور (نفس طريقة Word 2010+ بخوارزمية SHA-512)."""
    v = _xor_verifier2(pw)
    legacy = '%02X%02X%02X%02X' % (v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF, (v >> 24) & 0xFF)
    salt = secrets.token_bytes(16)
    spin = 100000
    h = hashlib.sha512(salt + legacy.encode('utf-16-le')).digest()
    for i in range(spin):
        h = hashlib.sha512(h + i.to_bytes(4, 'little')).digest()
    return ('<w:documentProtection w:edit="readOnly" w:enforcement="1" w:cryptProviderType="rsaAES" '
            'w:cryptAlgorithmClass="hash" w:cryptAlgorithmType="typeAny" w:cryptAlgorithmSid="14" '
            'w:cryptSpinCount="%d" w:hash="%s" w:salt="%s"/>' % (spin, base64.b64encode(h).decode(), base64.b64encode(salt).decode()))


def _grid(head_rows):
    """يحوّل صفوف الرأس (بـ colspan/rowspan) لشبكة: كل خلية ومكانها."""
    occ = {}
    placed = []
    ncols = 0
    for r, row in enumerate(head_rows):
        c = 0
        for cell in row:
            while (r, c) in occ:
                c += 1
            cs, rs = max(1, int(cell.get('cs') or 1)), max(1, int(cell.get('rs') or 1))
            placed.append((r, c, cs, rs, str(cell.get('t') or '')))
            for i in range(rs):
                for j in range(cs):
                    occ[(r + i, c + j)] = True
            c += cs
            ncols = max(ncols, c)
    return placed, ncols


def _clean(payload):
    head = [[{'t': str(c.get('t', ''))[:500], 'cs': int(c.get('cs') or 1), 'rs': int(c.get('rs') or 1)}
             for c in (row or [])] for row in (payload.get('head') or [])][:4]
    rows = []
    for r in (payload.get('rows') or [])[:20000]:
        rows.append({'c': [{'t': str(c.get('t', ''))[:2000], 'cs': int(c.get('cs') or 1)} for c in (r.get('c') or [])],
                     'tot': bool(r.get('tot'))})
    return head, rows


def _widths(placed, ncols, rows):
    w = [4.0] * ncols
    for (r, c, cs, rs, t) in placed:
        if cs == 1:
            w[c] = max(w[c], min(14, max((len(x) for x in t.split()), default=2)))
    for row in rows[:800]:
        c = 0
        for cell in row['c']:
            if cell['cs'] == 1 and c < ncols:
                longest = max((len(x) for x in cell['t'].split('\n')), default=0)
                w[c] = max(w[c], min(34, longest))
            c += cell['cs']
    return w


def _logo_bytes(payload):
    s = str(payload.get('logo') or '')
    if s.startswith('data:image/png;base64,'):
        try:
            return base64.b64decode(s.split(',', 1)[1])
        except ValueError:
            return b''
    return b''


# ───── Excel ─────
def export_xlsx(payload, pw):
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.workbook.protection import WorkbookProtection
    head, rows = _clean(payload)
    placed, ncols = _grid(head)
    for r in rows:
        ncols = max(ncols, sum(c['cs'] for c in r['c']))
    ncols = max(ncols, 2)
    tiny = bool(payload.get('tiny'))
    F = 'Arial'
    fs = 8 if tiny else 10
    wb = Workbook()
    ws = wb.active
    ws.title = 'الكشف'
    ws.sheet_view.rightToLeft = True
    ws.sheet_view.showGridLines = False
    ink = '1C1B33'
    thin = Side(style='thin', color='999999')
    box = Border(left=thin, right=thin, top=thin, bottom=thin)
    head_fill = PatternFill('solid', fgColor='EFEDE6')
    tot_fill = PatternFill('solid', fgColor='F4F2EC')
    widths = _widths(placed, ncols, rows)
    for i, wv in enumerate(widths):
        ws.column_dimensions[get_column_letter(i + 1)].width = round(wv * (0.95 if tiny else 1.1) + 2.5, 1)
    side = max(1, min(ncols // 2, 4))

    def put(r, c1, c2, text, size, bold=False, color=ink, align='right', merge=True, wrap=False):
        if merge and c2 > c1:
            ws.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
        cell = ws.cell(row=r, column=c1, value=text)
        cell.font = Font(name=F, size=size, bold=bold, color=color)
        cell.alignment = Alignment(horizontal=align, vertical='center', wrap_text=wrap, readingOrder=2)
        return cell
    # رأس الكشف
    put(1, 1, side, 'النيابة العامة', 15, True, align='center')
    put(2, 1, side, payload.get('kulliya', ''), 13, True, align='center')
    put(3, 1, side, payload.get('juz', ''), 13, True, align='center')
    for r in (1, 2, 3):
        ws.row_dimensions[r].height = 22
    logo = _logo_bytes(payload)
    if logo:
        try:
            from openpyxl.drawing.image import Image as XLImage
            img = XLImage(io.BytesIO(logo))
            img.width, img.height = 76, 76
            ws.add_image(img, get_column_letter(ncols) + '1')
        except Exception:
            pass
    rule = Side(style='double', color=ink)
    for c in range(1, ncols + 1):
        ws.cell(row=4, column=c).border = Border(bottom=rule)
    ws.row_dimensions[4].height = 8
    put(6, 1, ncols, payload.get('title', ''), 14, True, align='center')
    ws.row_dimensions[6].height = 24
    put(7, 1, ncols, payload.get('sub', ''), 9, False, '666666', align='center')
    # رأس الجدول
    top = 9
    nh = max([p[0] + p[3] for p in placed] + [1]) if placed else 0
    for (r, c, cs, rs, t) in placed:
        rr, cc = top + r, 1 + c
        if cs > 1 or rs > 1:
            ws.merge_cells(start_row=rr, start_column=cc, end_row=rr + rs - 1, end_column=cc + cs - 1)
        cell = ws.cell(row=rr, column=cc, value=t)
        cell.font = Font(name=F, size=fs, bold=True, color=ink)
        cell.alignment = Alignment(horizontal='center' if cs > 1 else 'right', vertical='center', wrap_text=True, readingOrder=2)
        for i in range(rs):
            for j in range(cs):
                x = ws.cell(row=rr + i, column=cc + j)
                x.fill = head_fill
                x.border = box
    for i in range(nh):
        ws.row_dimensions[top + i].height = 30 if tiny else 24
    # البيانات
    r0 = top + nh
    for k, row in enumerate(rows):
        rr = r0 + k
        c = 1
        lines = 1
        for cell in row['c']:
            if c > ncols:
                break
            t = cell['t']
            val = t
            if t and re.fullmatch(r'[0-9٠-٩]+', t):
                val = int(t.translate(str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789')))
            if cell['cs'] > 1:
                ws.merge_cells(start_row=rr, start_column=c, end_row=rr, end_column=min(ncols, c + cell['cs'] - 1))
            x = ws.cell(row=rr, column=c, value=val)
            x.font = Font(name=F, size=fs, bold=row['tot'], color='222222')
            x.alignment = Alignment(horizontal='center' if cell['cs'] > 1 else 'right', vertical='center', wrap_text=True, readingOrder=2)
            span_w = sum(widths[c - 1:c - 1 + cell['cs']]) or 4
            est = sum(max(1, -(-len(part) // max(1, int(span_w * 1.05)))) for part in t.split('\n')) if t else 1
            lines = max(lines, est)
            for j in range(cell['cs']):
                y = ws.cell(row=rr, column=min(ncols, c + j))
                y.border = box
                if row['tot']:
                    y.fill = tot_fill
            c += cell['cs']
        ws.row_dimensions[rr].height = max(18, (12 if tiny else 14) * lines + 4)
    end = r0 + len(rows)
    # التذييل
    f0 = end + 2
    put(f0, 1, side, 'تحريراً في', 10, True, '555555', align='center')
    put(f0 + 1, 1, side, payload.get('date', ''), 11, True, align='center')
    lc1 = max(side + 1, ncols - side + 1)
    put(f0, lc1, ncols, (payload.get('chiefTitle') or 'رئيس النيابة'), 13, True, align='center')
    put(f0 + 1, lc1, ncols, payload.get('chief') or '..............................', 13, True, align='center')
    nxt = f0 + 3
    if payload.get('credit'):
        put(nxt, 1, ncols, 'تم إعداده وتصميمه بمعرفة / محمود القاضي — وكيل النائب العام بنيابة أول وثالث أكتوبر', 8, False, '999999')
        nxt += 1
    if payload.get('edited'):
        put(nxt, 1, ncols, 'تم تعديله', 8, False, '999999')
    # الطباعة
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.paperSize = 9
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    ws.page_margins.left = ws.page_margins.right = 0.4
    ws.page_margins.top = ws.page_margins.bottom = 0.5
    if nh:
        ws.print_title_rows = '%d:%d' % (top, top + nh - 1)
        ws.freeze_panes = ws.cell(row=top + nh, column=1)
    # الحماية بكلمة مرور تعديل الكشوف
    if pw:
        ws.protection.sheet = True
        ws.protection.password = pw
        ws.protection.formatColumns = False
        ws.protection.formatRows = False
        ws.protection.autoFilter = False
        ws.protection.sort = False
        wb.security = WorkbookProtection(workbookPassword=pw, lockStructure=True)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ───── Word ─────
_W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
_R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'


def _run(text, sz, bold=False, color='1C1B33'):
    rpr = ('<w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>' + ('<w:b/><w:bCs/>' if bold else '') +
           '<w:color w:val="%s"/><w:sz w:val="%d"/><w:szCs w:val="%d"/><w:rtl/></w:rPr>' % (color, sz, sz))
    parts = str(text).split('\n')
    out = []
    for i, p in enumerate(parts):
        if i:
            out.append('<w:r>' + rpr + '<w:br/></w:r>')
        out.append('<w:r>' + rpr + '<w:t xml:space="preserve">' + _x(p) + '</w:t></w:r>')
    return ''.join(out)


def _p(inner, jc=None, before=0, after=0, extra=''):
    return ('<w:p><w:pPr>' + extra + '<w:bidi/><w:spacing w:before="%d" w:after="%d" w:line="240" w:lineRule="auto"/>' % (before, after) +
            ('<w:jc w:val="%s"/>' % jc if jc else '') + '</w:pPr>' + inner + '</w:p>')


def _tc(width, inner, span=1, vmerge=None, fill=None, borders=True):
    pr = '<w:tcW w:w="%d" w:type="dxa"/>' % width
    if span > 1:
        pr += '<w:gridSpan w:val="%d"/>' % span
    if vmerge == 'restart':
        pr += '<w:vMerge w:val="restart"/>'
    elif vmerge == 'cont':
        pr += '<w:vMerge/>'
    if not borders:
        pr += '<w:tcBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/></w:tcBorders>'
    if fill:
        pr += '<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % fill
    pr += '<w:vAlign w:val="center"/>'
    return '<w:tc><w:tcPr>' + pr + '</w:tcPr>' + inner + '</w:tc>'


def _drawing(rid, emu, pid):
    return ('<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="%d" cy="%d"/>'
            '<wp:docPr id="%d" name="logo%d"/><wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/></wp:cNvGraphicFramePr>'
            '<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
            '<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="0" name="logo.png"/><pic:cNvPicPr/></pic:nvPicPr>'
            '<pic:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
            '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>'
            '</a:graphicData></a:graphic></wp:inline></w:drawing></w:r>') % (emu, emu, pid, pid, rid, emu, emu)


_NS = ('xmlns:w="%s" xmlns:r="%s" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
       'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
       'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"') % (_W, _R)
_NOB = ('<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/>'
        '<w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders>')


def export_docx(payload, pw):
    head, rows = _clean(payload)
    placed, ncols = _grid(head)
    for r in rows:
        ncols = max(ncols, sum(c['cs'] for c in r['c']))
    ncols = max(ncols, 1)
    tiny = bool(payload.get('tiny'))
    usable = 16838 - 2 * 567
    w = _widths(placed, ncols, rows)
    ctw = 92 if tiny else 112
    need = [int(x * ctw + 160) for x in w]
    short = [i for i in range(ncols) if w[i] <= 14]
    longs = [i for i in range(ncols) if w[i] > 14]
    rest = usable - sum(need[i] for i in short)
    if sum(need) <= usable:
        k = usable / float(sum(need))
        cw = [int(x * k) for x in need]
    elif longs and rest >= 900 * len(longs):
        lw = float(sum(w[i] for i in longs))
        cw = [need[i] if i in short else int(rest * w[i] / lw) for i in range(ncols)]
    else:
        k = usable / float(sum(need))
        cw = [max(200, int(x * k)) for x in need]
    cw[max(range(ncols), key=lambda i: cw[i])] += usable - sum(cw)
    sz = 14 if tiny else 18
    ink = '1C1B33'
    logo = _logo_bytes(payload)
    # جدول البيانات
    tbl = ['<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="%d" w:type="dxa"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/>' % usable,
           '<w:tblBorders>' + ''.join('<w:%s w:val="single" w:sz="4" w:space="0" w:color="999999"/>' % s
                                     for s in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV')) + '</w:tblBorders>',
           '<w:tblCellMar><w:top w:w="30" w:type="dxa"/><w:left w:w="70" w:type="dxa"/><w:bottom w:w="30" w:type="dxa"/><w:right w:w="70" w:type="dxa"/></w:tblCellMar>',
           '</w:tblPr><w:tblGrid>' + ''.join('<w:gridCol w:w="%d"/>' % x for x in cw) + '</w:tblGrid>']
    nh = max([p[0] + p[3] for p in placed] + [0])
    starts = {(p[0], p[1]): p for p in placed}
    cover = {}
    for (r, c, cs, rs, t) in placed:
        for i in range(1, rs):
            cover[(r + i, c)] = (cs, t)
    for r in range(nh):
        cells = []
        c = 0
        while c < ncols:
            if (r, c) in starts:
                _, _, cs, rs, t = starts[(r, c)]
                cells.append(_tc(sum(cw[c:c + cs]), _p(_run(t, sz, True, ink), 'center' if cs > 1 else None), cs,
                                 'restart' if rs > 1 else None, 'EFEDE6'))
                c += cs
            elif (r, c) in cover:
                cs = cover[(r, c)][0]
                cells.append(_tc(sum(cw[c:c + cs]), _p(''), cs, 'cont', 'EFEDE6'))
                c += cs
            else:
                cells.append(_tc(cw[c], _p(''), 1, None, 'EFEDE6'))
                c += 1
        tbl.append('<w:tr><w:trPr><w:cantSplit/><w:tblHeader/></w:trPr>' + ''.join(cells) + '</w:tr>')
    for row in rows:
        cells = []
        c = 0
        for cell in row['c']:
            if c >= ncols:
                break
            cs = min(cell['cs'], ncols - c)
            cells.append(_tc(sum(cw[c:c + cs]), _p(_run(cell['t'], sz, row['tot'], '222222'), 'center' if cs > 1 else None), cs,
                             None, 'F4F2EC' if row['tot'] else None))
            c += cs
        while c < ncols:
            cells.append(_tc(cw[c], _p('')))
            c += 1
        tbl.append('<w:tr><w:trPr><w:cantSplit/></w:trPr>' + ''.join(cells) + '</w:tr>')
    tbl.append('</w:tbl>')
    body = (_p(_run(payload.get('title', ''), 28, True, ink), 'center', 60, 20) +
            _p(_run(payload.get('sub', ''), 17, False, '666666'), 'center', 0, 120) + ''.join(tbl) + _p(''))
    sect = ('<w:sectPr><w:headerReference w:type="default" r:id="rIdH"/><w:footerReference w:type="default" r:id="rIdF"/>'
            '<w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/>'
            '<w:pgMar w:top="567" w:right="567" w:bottom="567" w:left="567" w:header="400" w:footer="400" w:gutter="0"/><w:bidi/></w:sectPr>')
    document = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document %s><w:body>' % _NS) + body + sect + '</w:body></w:document>'
    # رأس الصفحة (الترويسة) — يتكرر في كل صفحة زي الكشف
    right = (_p(_run('النيابة العامة', 32, True, ink), 'center', 0, 20,
                '<w:pBdr><w:bottom w:val="single" w:sz="8" w:space="1" w:color="1C1B33"/></w:pBdr>') +
             _p(_run(payload.get('kulliya', ''), 26, True, ink), 'center') + _p(_run(payload.get('juz', ''), 26, True, ink), 'center'))
    left = _p(_drawing('rIdLogo', 900000, 11) if logo else '', 'left')
    header = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:hdr %s>' % _NS +
              '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="%d" w:type="dxa"/><w:tblLayout w:type="fixed"/>%s</w:tblPr>' % (usable, _NOB) +
              '<w:tblGrid><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/></w:tblGrid><w:tr>' % (4200, usable - 4200 - 2000, 2000) +
              _tc(4200, right, borders=False) + _tc(usable - 6200, _p(''), borders=False) + _tc(2000, left, borders=False) + '</w:tr></w:tbl>' +
              _p('', None, 60, 0, '<w:pBdr><w:bottom w:val="double" w:sz="6" w:space="1" w:color="1C1B33"/></w:pBdr>') + '</w:hdr>')
    fr = _p(_run('تحريراً في', 18, True, '555555'), 'center') + _p(_run(payload.get('date', ''), 20, True, ink), 'center')
    fl = _p(_run(payload.get('chiefTitle') or 'رئيس النيابة', 26, True, ink), 'center') + _p(_run(payload.get('chief') or '..............................', 26, True, ink), 'center')
    notes = ''
    if payload.get('credit'):
        notes += _p(_run('تم إعداده وتصميمه بمعرفة / محمود القاضي — وكيل النائب العام بنيابة أول وثالث أكتوبر', 14, False, '999999'), None, 40)
    if payload.get('edited'):
        notes += _p(_run('تم تعديله', 14, False, '999999'))
    footer = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr %s>' % _NS +
              '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="%d" w:type="dxa"/><w:tblLayout w:type="fixed"/>%s</w:tblPr>' % (usable, _NOB) +
              '<w:tblGrid><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/></w:tblGrid><w:tr>' % (3200, usable - 3200 - 4200, 4200) +
              _tc(3200, fr, borders=False) + _tc(usable - 7400, _p(''), borders=False) + _tc(4200, fl, borders=False) + '</w:tr></w:tbl>' +
              (notes or _p('')) + '</w:ftr>')
    styles = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="%s"><w:docDefaults><w:rPrDefault><w:rPr>'
              '<w:rFonts w:ascii="Arial" w:eastAsia="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:sz w:val="20"/><w:szCs w:val="20"/>'
              '<w:lang w:val="ar-EG" w:eastAsia="en-US" w:bidi="ar-EG"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:bidi/>'
              '<w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>'
              '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>'
              '<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/>'
              '<w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>'
              '</w:styles>') % _W
    settings = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings xmlns:w="%s">' % _W + (word_protection_xml(pw) if pw else '') +
                '<w:defaultTabStop w:val="720"/><w:characterSpacingControl w:val="doNotCompress"/>'
                '<w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat></w:settings>')
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          '<Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/>'
          '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
          '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
          '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>'
          '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>'
          '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>'
          '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>')
    drels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
             '<Relationship Id="rIdS" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
             '<Relationship Id="rIdT" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>'
             '<Relationship Id="rIdH" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>'
             '<Relationship Id="rIdF" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>')
    hrels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
             ('<Relationship Id="rIdLogo" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/logo.png"/>' if logo else '') +
             '</Relationships>')
    now = dt.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
    core = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            '<dc:title>%s</dc:title><dc:creator>%s</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">%s</dcterms:created></cp:coreProperties>') % (
        _x(payload.get('title', '')), _x(payload.get('juz', '')), now)
    buf = io.BytesIO()
    with _zip.ZipFile(buf, 'w', _zip.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', ct)
        z.writestr('_rels/.rels', rels)
        z.writestr('docProps/core.xml', core)
        z.writestr('word/document.xml', document)
        z.writestr('word/styles.xml', styles)
        z.writestr('word/settings.xml', settings)
        z.writestr('word/header1.xml', header)
        z.writestr('word/footer1.xml', footer)
        z.writestr('word/_rels/document.xml.rels', drels)
        z.writestr('word/_rels/header1.xml.rels', hrels)
        if logo:
            z.writestr('word/media/logo.png', logo)
    return buf.getvalue()


# ───────────── حماية الكشوف (اختيارية في النسخة الشخصية) ─────────────
_encrypt_pdf_v8 = encrypt_pdf


def protect_pdf(data):
    """لو فيه كلمة مرور للكشوف من لوحة التحكم: AES-256 لو مكتبة التشفير موجودة، وإلا RC4-128."""
    pw = CFG.get('pdf_owner_password') or ''
    if not pw:
        return data, False
    out, ok = _encrypt_pdf_v8(data)
    if ok:
        return out, True
    try:
        from pypdf import PdfReader, PdfWriter
        from pypdf.constants import UserAccessPermissions
        w = PdfWriter()
        w.append_pages_from_reader(PdfReader(io.BytesIO(data)))
        w.encrypt(user_password='', owner_password=pw, algorithm='RC4-128',
                  permissions_flag=UserAccessPermissions.PRINT | UserAccessPermissions.PRINT_TO_REPRESENTATION)
        buf = io.BytesIO()
        w.write(buf)
        return buf.getvalue(), True
    except Exception as exc:
        log('  PDF protection skipped:', exc)
        return data, False


# ───────────── محضر التحقيق Word ─────────────
QA_RE = re.compile(r'^\s*(س|ج)\s*[:：/\-–)]\s*(.*)$')


def _rf(text, hp, bold=False, font='Simplified Arabic', color='000000', underline=False):
    rpr = ('<w:rPr><w:rFonts w:ascii="%s" w:hAnsi="%s" w:cs="%s"/>' % (_x(font), _x(font), _x(font)) +
           ('<w:b/><w:bCs/>' if bold else '') + ('<w:u w:val="single"/>' if underline else '') +
           '<w:color w:val="%s"/><w:sz w:val="%d"/><w:szCs w:val="%d"/><w:rtl/></w:rPr>' % (color, hp, hp))
    return '<w:r>' + rpr + '<w:t xml:space="preserve">' + _x(text) + '</w:t></w:r>'


def _pf(inner, jc='both', before=0, after=0, line=360, extra=''):
    return ('<w:p><w:pPr>' + extra + '<w:bidi/><w:spacing w:before="%d" w:after="%d" w:line="%d" w:lineRule="auto"/>' % (before, after, line) +
            '<w:jc w:val="%s"/></w:pPr>' % jc + inner + '</w:p>')


def export_inv_docx(p):
    font = str(p.get('font') or 'Simplified Arabic')[:60]
    try:
        size = max(9, min(24, float(p.get('size') or 14)))
    except (TypeError, ValueError):
        size = 14
    hp = int(round(size * 2))
    ink = '000000'
    usable = 11906 - 2 * 1134
    logo = _logo_bytes(p)
    body = []
    if p.get('title'):
        body.append(_pf(_rf(p['title'], hp + 6, True, font, ink, True), 'center', 0, 60))
    if p.get('sub'):
        body.append(_pf(_rf(p['sub'], hp - 2, False, font, '333333'), 'center', 0, 160))
    for line in [str(x) for x in (p.get('lines') or [])][:6000]:
        line = line.rstrip()
        if not line.strip():
            body.append(_pf('', 'both', 0, 0))
            continue
        m = QA_RE.match(line)
        if m:
            body.append(_pf(_rf(m.group(1) + ': ', hp, True, font, ink) + _rf(m.group(2), hp, False, font, ink), 'both', 0, 40))
        elif line.strip().startswith('##'):
            body.append(_pf(_rf(line.strip().lstrip('#').strip(), hp, True, font, ink, True), 'center', 120, 60))
        else:
            body.append(_pf(_rf(line, hp, False, font, ink), 'both', 0, 40))
    sr = p.get('signRight') or {}
    sl = p.get('signLeft') or {}
    sign = ('<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="%d" w:type="dxa"/><w:tblLayout w:type="fixed"/>%s</w:tblPr>' % (usable, _NOB) +
            '<w:tblGrid><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/></w:tblGrid><w:tr>' % (usable // 2, usable - usable // 2) +
            _tc(usable // 2, _pf(_rf(str(sr.get('k') or ''), hp, True, font, ink), 'center', 0, 0) +
                _pf(_rf(str(sr.get('v') or ''), hp, False, font, ink), 'center', 0, 0), borders=False) +
            _tc(usable - usable // 2, _pf(_rf(str(sl.get('k') or ''), hp, True, font, ink), 'center', 0, 0) +
                _pf(_rf(str(sl.get('v') or ''), hp, False, font, ink), 'center', 0, 0), borders=False) +
            '</w:tr></w:tbl>')
    body.append(_pf('', 'both', 240, 0))
    body.append(sign)
    sect = ('<w:sectPr><w:headerReference w:type="default" r:id="rIdH"/><w:footerReference w:type="default" r:id="rIdF"/>'
            '<w:pgSz w:w="11906" w:h="16838"/>'
            '<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="500" w:footer="500" w:gutter="0"/><w:bidi/></w:sectPr>')
    document = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document %s><w:body>' % _NS) + ''.join(body) + sect + '</w:body></w:document>'
    hdr_font = 'Arial'
    right = (_pf(_rf('النيابة العامة', 28, True, hdr_font, ink), 'center', 0, 20, 240,
                 '<w:pBdr><w:bottom w:val="single" w:sz="8" w:space="1" w:color="000000"/></w:pBdr>') +
             _pf(_rf(str(p.get('kulliya') or ''), 24, True, hdr_font, ink), 'center', 0, 0, 240) +
             _pf(_rf(str(p.get('juz') or ''), 24, True, hdr_font, ink), 'center', 0, 0, 240))
    left = _p(_drawing('rIdLogo', 760000, 11) if logo else '', 'left')
    header = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:hdr %s>' % _NS +
              '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="%d" w:type="dxa"/><w:tblLayout w:type="fixed"/>%s</w:tblPr>' % (usable, _NOB) +
              '<w:tblGrid><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/></w:tblGrid><w:tr>' % (3900, usable - 3900 - 1700, 1700) +
              _tc(3900, right, borders=False) + _tc(usable - 5600, _p(''), borders=False) + _tc(1700, left, borders=False) + '</w:tr></w:tbl>' +
              _p('', None, 40, 0, '<w:pBdr><w:bottom w:val="double" w:sz="6" w:space="1" w:color="000000"/></w:pBdr>') + '</w:hdr>')
    fr = lambda t: '<w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:sz w:val="18"/><w:szCs w:val="18"/><w:rtl/></w:rPr><w:t xml:space="preserve">%s</w:t></w:r>' % _x(t)
    fld = lambda instr: ('<w:fldSimple w:instr="%s"><w:r><w:rPr><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr><w:t>1</w:t></w:r></w:fldSimple>' % instr)
    footer = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr %s>' % _NS +
              '<w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr>' + fr('صفحة ') + fld('PAGE') + fr(' من ') + fld('NUMPAGES') + '</w:p></w:ftr>')
    styles = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="%s"><w:docDefaults><w:rPrDefault><w:rPr>'
              '<w:rFonts w:ascii="%s" w:eastAsia="%s" w:hAnsi="%s" w:cs="%s"/><w:sz w:val="%d"/><w:szCs w:val="%d"/>'
              '<w:lang w:val="ar-EG" w:eastAsia="en-US" w:bidi="ar-EG"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:bidi/>'
              '<w:spacing w:after="0" w:line="360" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>'
              '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>'
              '<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/>'
              '<w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>'
              '</w:styles>') % (_W, _x(font), _x(font), _x(font), _x(font), hp, hp)
    settings = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings xmlns:w="%s">' % _W +
                '<w:defaultTabStop w:val="720"/><w:characterSpacingControl w:val="doNotCompress"/>'
                '<w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat></w:settings>')
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          '<Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/>'
          '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
          '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
          '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>'
          '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>'
          '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>'
          '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>')
    drels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
             '<Relationship Id="rIdS" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
             '<Relationship Id="rIdT" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>'
             '<Relationship Id="rIdH" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>'
             '<Relationship Id="rIdF" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>')
    hrels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
             ('<Relationship Id="rIdLogo" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/logo.png"/>' if logo else '') +
             '</Relationships>')
    now = dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    core = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            '<dc:title>%s</dc:title><dc:creator>%s</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">%s</dcterms:created></cp:coreProperties>') % (
        _x(str(p.get('title') or 'محضر تحقيق')), _x(str(p.get('juz') or '')), now)
    buf = io.BytesIO()
    with _zip.ZipFile(buf, 'w', _zip.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', ct)
        z.writestr('_rels/.rels', rels)
        z.writestr('docProps/core.xml', core)
        z.writestr('word/document.xml', document)
        z.writestr('word/styles.xml', styles)
        z.writestr('word/settings.xml', settings)
        z.writestr('word/header1.xml', header)
        z.writestr('word/footer1.xml', footer)
        z.writestr('word/_rels/document.xml.rels', drels)
        z.writestr('word/_rels/header1.xml.rels', hrels)
        if logo:
            z.writestr('word/media/logo.png', logo)
    return buf.getvalue()


# ───────────── الذكاء الاصطناعي (اختياري — محتاج نت ومفتاح) ─────────────
DEFAULT_MODEL = 'claude-sonnet-5-5'


def ai_settings():
    s = (STATE or {}).get('settings') or {}
    key = ((STATE or {}).get('secrets') or {}).get('aiKey') or ''
    return bool(s.get('aiEnabled')), key, (str(s.get('aiModel') or '').strip() or DEFAULT_MODEL)


def ai_call(system, content, max_tokens=4000):
    enabled, key, model = ai_settings()
    if not enabled:
        raise ValueError('الذكاء الاصطناعي مقفول من لوحة التحكم')
    if not key:
        raise ValueError('مفيش مفتاح للذكاء الاصطناعي — ضيفه من لوحة التحكم')
    body = json.dumps({'model': model, 'max_tokens': max_tokens, 'system': system,
                       'messages': [{'role': 'user', 'content': content}]}).encode('utf-8')
    req = urllib.request.Request('https://api.anthropic.com/v1/messages', data=body, method='POST', headers={
        'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            out = json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode('utf-8')).get('error', {}).get('message', '')
        except Exception:
            msg = ''
        raise ValueError('خدمة الذكاء الاصطناعي ردت بخطأ %d %s' % (e.code, msg))
    except (urllib.error.URLError, socket.timeout, OSError):
        raise ValueError('مفيش اتصال بالنت أو الخدمة مش متاحة دلوقتي')
    return ''.join(b.get('text', '') for b in out.get('content', []) if b.get('type') == 'text').strip()


OCR_SYSTEM = (
    'أنت مساعد تفريغ نصوص لوكيل نيابة مصري. هتوصلك صورة لورقة (محضر أو أقوال أو مستند). '
    'فرّغ النص العربي المكتوب في الصورة حرفياً بدون أي إضافة أو تلخيص أو تصحيح للمعنى. '
    'لو الورقة فيها أسئلة وأجوبة اكتب كل سؤال في سطر يبدأ بـ «س: » وكل إجابة في سطر يبدأ بـ «ج: ». '
    'لو فيه كلمة مش مقروءة اكتب مكانها [غير مقروء]. اكتب الأرقام زي ما هي. '
    'رجّع النص المفرّغ بس من غير أي مقدمة أو تعليق.')

QBANK_SYSTEM = (
    'أنت مساعد لوكيل نيابة مصري بيجهّز بنك أسئلة للتحقيقات. هيوصلك نوع القضية وقائمة أسئلة اتسألت فعلاً في تحقيقات سابقة. '
    'رتّب الأسئلة تحت عناوين بتغطي الواقعة كلها بالترتيب المنطقي للتحقيق (مثلاً: بيانات المسئول، الواقعة وظروفها، التحريات، الضبط والتفتيش، المضبوطات، المتهم وأقواله، الشهود، الإصابات أو التلفيات، الإجراءات). '
    'ادمج الأسئلة المكررة في المعنى في سؤال واحد بصياغة سليمة، ومتغيرش معنى أي سؤال. '
    'لو فيه أسئلة مهمة ناقصة في نوع القضية ده ضيفها في خانة suggested لكل عنوان. '
    'رجّع JSON بس بالشكل ده من غير أي كلام تاني: {"sections":[{"title":"...","questions":["..."],"suggested":["..."]}]}')


def tesseract_path():
    for c in [BASE / 'tesseract' / 'tesseract.exe', BASE / 'tesseract' / 'tesseract']:
        if c.exists():
            return str(c)
    w = shutil.which('tesseract')
    if w:
        return w
    for c in [r'C:\Program Files\Tesseract-OCR\tesseract.exe', r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe']:
        if os.path.exists(c):
            return c
    return None


def local_ocr(img_bytes, ext):
    exe = tesseract_path()
    if not exe:
        raise ValueError('التفريغ من غير نت محتاج برنامج Tesseract مع اللغة العربية (فولدر tesseract جنب البرنامج)')
    with tempfile.TemporaryDirectory(prefix='maktabi-ocr-') as td:
        src = Path(td) / ('img.' + ext)
        src.write_bytes(img_bytes)
        cmd = [exe, str(src), 'stdout', '-l', 'ara']
        tdata = Path(exe).parent / 'tessdata'
        if tdata.is_dir():
            cmd[1:1] = ['--tessdata-dir', str(tdata)]
        kw = {'creationflags': 0x08000000} if os.name == 'nt' else {}
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180, **kw)
        txt = r.stdout.decode('utf-8', 'replace').strip()
        if r.returncode != 0 and not txt:
            raise ValueError('Tesseract ما قدرش يقرا الصورة: ' + r.stderr.decode('utf-8', 'replace')[:200])
        return txt


def parse_data_url(s):
    m = re.match(r'data:(image/(png|jpeg|jpg|webp|gif));base64,(.+)$', str(s or ''), re.S)
    if not m:
        raise ValueError('الصورة مش مقروءة — استخدم JPG أو PNG')
    return m.group(1).replace('jpg', 'jpeg'), base64.b64decode(m.group(3))


# ───────────── السيرفر ─────────────
class Handler(BaseHTTPRequestHandler):
    server_version = 'Maktabi/1.0'

    def log_message(self, fmt, *args):
        pass

    def reply(self, status=200, data=None, raw=None, ctype='application/json; charset=utf-8', headers=None):
        content = raw if raw is not None else json.dumps(data if data is not None else {}, ensure_ascii=False,
                                                         separators=(',', ':')).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(content)))
        if ctype.startswith(('font/', 'text/css')):
            self.send_header('Cache-Control', 'public, max-age=2592000')
        else:
            self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy',
                         "default-src 'self' data: blob:; script-src 'self' 'unsafe-inline'; "
                         "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
                         "font-src 'self' data: https://fonts.gstatic.com; img-src 'self' data: blob:; "
                         "connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
        if headers:
            for k, v in headers.items():
                self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(content)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def err(self, msg, code=400):
        self.reply(code, {'ok': False, 'error': str(msg)})

    def get_body(self):
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            raise ValueError('حجم الطلب غير صالح')
        if length <= 0 or length > MAX_UPLOAD:
            raise ValueError('حجم الملف غير صالح أو أكبر من ٤٠ ميجابايت')
        return self.rfile.read(length)

    def get_json(self):
        return json.loads(self.get_body().decode('utf-8'))

    def host_ok(self):
        h = (self.headers.get('Host') or '').split(':')[0].lower()
        return h in ('127.0.0.1', 'localhost') or h in EXTRA_HOSTS

    def touch(self):
        global LAST_ACT
        LAST_ACT = time.time()

    def locked(self):
        return self.reply(401, {'ok': False, 'locked': True, 'error': 'البرنامج مقفول — اكتب كلمة السر'})

    def do_GET(self):
        if not self.host_ok():
            return self.err('غير مسموح', 403)
        check_idle()
        path = urlsplit(self.path).path
        if path in ('/', '/index.html'):
            return self.reply(raw=(BASE / 'index.html').read_bytes(), ctype='text/html; charset=utf-8')
        if path.startswith('/fonts/'):
            name = path[len('/fonts/'):]
            if not re.fullmatch(r'[a-zA-Z0-9_.-]+\.(css|woff2)', name):
                return self.err('غير موجود', 404)
            f = FONTS_DIR / name
            ct = 'text/css; charset=utf-8' if name.endswith('.css') else 'font/woff2'
            return self.reply(raw=f.read_bytes() if f.exists() else b'', ctype=ct)
        if path == '/favicon.ico':
            return self.reply(raw=b'', ctype='image/x-icon')
        if path == '/api/status':
            return self.reply(data={'ok': True, 'setup': VAULT.exists(), 'unlocked': session_ok(self),
                                    'open': KEY is not None, 'version': APP_VERSION})
        if not session_ok(self):
            return self.locked()
        if path == '/api/version':
            return self.reply(data={'v': VERSION})
        self.touch()
        if path == '/api/data':
            with LOCK:
                return self.reply(data={'v': VERSION, 'data': public_state()})
        if path == '/api/info':
            try:
                import openpyxl  # noqa: F401
                xl = True
            except ImportError:
                xl = False
            enabled, key, model = ai_settings()
            return self.reply(data={'ok': True, 'pdf': bool(find_browser()), 'fonts': (FONTS_DIR / 'fonts.css').exists(),
                                    'excel': xl, 'tesseract': bool(tesseract_path()), 'aiKey': bool(key), 'aiModel': model,
                                    'data': str(DATA_DIR), 'port': PORT, 'version': APP_VERSION, 'server': SERVER_MODE,
                                    'backups': len(list(BACKUP_DIR.glob('*.bin'))) if BACKUP_DIR.exists() else 0})
        if path == '/api/backup':
            with LOCK:
                raw = VAULT.read_bytes()
            name = 'maktabi-backup-' + dt.datetime.now().strftime('%Y-%m-%d') + '.bin'
            return self.reply(raw=raw, ctype='application/octet-stream',
                              headers={'Content-Disposition': 'attachment; filename="%s"' % name})
        return self.err('المسار غير موجود', 404)

    def do_POST(self):
        global KEY, STATE, VERSION
        if not self.host_ok():
            return self.err('غير مسموح', 403)
        check_idle()
        path = urlsplit(self.path).path
        try:
            if path == '/api/setup':
                o = self.get_json()
                pw = str(o.get('password') or '')
                if len(pw) < 6:
                    return self.err('كلمة السر لازم ٦ حروف أو أرقام على الأقل')
                with LOCK:
                    if VAULT.exists():
                        return self.err('البرنامج متجهز قبل كده — افتحه بكلمة السر')
                    KEY = new_key(pw)
                    STATE = blank_state()
                    VERSION = 1
                    write_vault(STATE)
                    tok = make_session()
                    self.touch()
                return self.reply(data={'ok': True}, headers={'Set-Cookie': 'maktabi=' + tok + '; HttpOnly; SameSite=Strict; Path=/' + COOKIE_SEC})
            if path == '/api/unlock':
                if too_many_fails():
                    return self.err('محاولات كتير غلط — استنى ' + ('١٥' if SERVER_MODE else '١٠') + ' دقيقة', 429)
                pw = str(self.get_json().get('password') or '')
                with LOCK:
                    if not VAULT.exists():
                        return self.err('لسه مفيش بيانات — جهّز البرنامج الأول')
                    raw = VAULT.read_bytes()
                    try:
                        data, key = open_vault(raw, pw)
                    except PermissionError as exc:
                        FAILS.append(time.time())
                        return self.err(str(exc), 403)
                    if KEY is None:
                        KEY, STATE, VERSION = key, data, VERSION + 1
                    CFG['pdf_owner_password'] = (STATE.get('secrets') or {}).get('sheetPassword') or ''
                    tok = make_session()
                    self.touch()
                    backup('open')
                return self.reply(data={'ok': True}, headers={'Set-Cookie': 'maktabi=' + tok + '; HttpOnly; SameSite=Strict; Path=/' + COOKIE_SEC})
            if path == '/api/lock':
                lock_now()
                return self.reply(data={'ok': True}, headers={'Set-Cookie': 'maktabi=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' + COOKIE_SEC})
            if path == '/api/shutdown':
                if not session_ok(self):
                    return self.locked()
                lock_now()
                self.reply(data={'ok': True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            if not session_ok(self):
                return self.locked()
            if path == '/api/ping':
                self.touch()
                return self.reply(data={'ok': True})
            self.touch()
            if path == '/api/data':
                o = self.get_json()
                if not isinstance(o.get('data'), dict) or not isinstance(o['data'].get('cases'), list):
                    return self.err('بيانات غير صحيحة')
                with LOCK:
                    if o.get('v') != VERSION:
                        return self.reply(data={'ok': False, 'conflict': True, 'v': VERSION, 'data': public_state()})
                    save_state(o['data'])
                    return self.reply(data={'ok': True, 'v': VERSION})
            if path == '/api/snapshot':
                tag = re.sub(r'[^a-z0-9-]', '', str(self.get_json().get('tag') or 'manual'))[:30] or 'manual'
                with LOCK:
                    backup(tag, force=True)
                return self.reply(data={'ok': True})
            if path == '/api/password':
                o = self.get_json()
                old, new = str(o.get('old') or ''), str(o.get('new') or '')
                if len(new) < 6:
                    return self.err('كلمة السر الجديدة لازم ٦ حروف أو أرقام على الأقل')
                with LOCK:
                    try:
                        open_vault(VAULT.read_bytes(), old)
                    except PermissionError:
                        return self.err('كلمة السر الحالية غير صحيحة', 403)
                    backup('before-password', force=True)
                    KEY = new_key(new)
                    write_vault(STATE)
                return self.reply(data={'ok': True})
            if path == '/api/secret':
                o = self.get_json()
                name = str(o.get('name') or '')
                if name not in SECRET_KEYS:
                    return self.err('إعداد غير معروف')
                val = str(o.get('value') or '').strip()
                with LOCK:
                    STATE.setdefault('secrets', {})[name] = val
                    if name == 'sheetPassword':
                        CFG['pdf_owner_password'] = val
                    VERSION += 1
                    write_vault(STATE)
                return self.reply(data={'ok': True, 'v': VERSION})
            if path == '/api/restore':
                raw = self.get_body()
                read_header(raw)
                with LOCK:
                    backup('before-restore', force=True)
                    tmp = VAULT.with_name('vault.restore.tmp')
                    tmp.write_bytes(raw)
                    os.replace(tmp, VAULT)
                lock_now()
                return self.reply(data={'ok': True}, headers={'Set-Cookie': 'maktabi=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' + COOKIE_SEC})
            if path == '/api/pdf/render':
                o = self.get_json()
                html = str(o.get('html') or '')
                if '<html' not in html[:300]:
                    return self.err('محتوى الكشف غير صالح')
                pdf, protected = protect_pdf(html_to_pdf(html))
                title = re.sub(r'[\\/:*?"<>|\n\r]+', ' ', str(o.get('title') or 'كشف'))[:120].strip() or 'كشف'
                return self.reply(raw=pdf, ctype='application/pdf', headers={
                    'Content-Disposition': "attachment; filename=\"maktabi.pdf\"; filename*=UTF-8''" + quote(title + '.pdf'),
                    'X-Protected': '1' if protected else '0'})
            if path in ('/api/export/docx', '/api/export/xlsx'):
                o = self.get_json()
                if not isinstance(o.get('head'), list) or not isinstance(o.get('rows'), list):
                    return self.err('بيانات الكشف غير صالحة')
                pw = (STATE.get('secrets') or {}).get('sheetPassword') or ''
                fmt = path.rsplit('/', 1)[1]
                try:
                    blob = export_docx(o, pw) if fmt == 'docx' else export_xlsx(o, pw)
                except ImportError:
                    return self.err('دعم Excel محتاج فولدر pylibs جنب البرنامج', 500)
                ctype = ('application/vnd.openxmlformats-officedocument.wordprocessingml.document' if fmt == 'docx'
                         else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
                title = re.sub(r'[\\/:*?"<>|\n\r]+', ' ', str(o.get('title') or 'كشف'))[:120].strip() or 'كشف'
                return self.reply(raw=blob, ctype=ctype, headers={
                    'Content-Disposition': "attachment; filename=\"maktabi.%s\"; filename*=UTF-8''%s" % (fmt, quote(title + '.' + fmt))})
            if path == '/api/export/investigation':
                o = self.get_json()
                blob = export_inv_docx(o)
                title = re.sub(r'[\\/:*?"<>|\n\r]+', ' ', str(o.get('fileName') or o.get('title') or 'تحقيق'))[:120].strip() or 'تحقيق'
                return self.reply(raw=blob, ctype='application/vnd.openxmlformats-officedocument.wordprocessingml.document', headers={
                    'Content-Disposition': "attachment; filename=\"investigation.docx\"; filename*=UTF-8''" + quote(title + '.docx')})
            if path == '/api/ocr':
                o = self.get_json()
                mtype, img = parse_data_url(o.get('image'))
                if o.get('mode') == 'local':
                    return self.reply(data={'ok': True, 'text': local_ocr(img, mtype.split('/')[1])})
                hint = str(o.get('hint') or '')[:300]
                content = [{'type': 'image', 'source': {'type': 'base64', 'media_type': mtype, 'data': base64.b64encode(img).decode()}},
                           {'type': 'text', 'text': 'فرّغ الصورة دي.' + (' ملاحظة: ' + hint if hint else '')}]
                return self.reply(data={'ok': True, 'text': ai_call(OCR_SYSTEM, content, 6000)})
            if path == '/api/ai/qbank':
                o = self.get_json()
                qs = [str(q)[:400] for q in (o.get('questions') or [])][:400]
                if not qs:
                    return self.err('مفيش أسئلة')
                txt = ai_call(QBANK_SYSTEM, 'نوع القضية: ' + str(o.get('type') or '')[:120] + '\nالأسئلة:\n' + '\n'.join('- ' + q for q in qs), 8000)
                m = re.search(r'\{.*\}', txt, re.S)
                if not m:
                    return self.err('الرد ما كانش بالشكل المطلوب — جرّب تاني')
                res = json.loads(m.group(0))
                secs = []
                for s in (res.get('sections') or [])[:40]:
                    secs.append({'title': str(s.get('title') or '')[:120],
                                 'questions': [str(x)[:400] for x in (s.get('questions') or [])][:200],
                                 'suggested': [str(x)[:400] for x in (s.get('suggested') or [])][:60]})
                return self.reply(data={'ok': True, 'sections': secs})
            return self.err('المسار غير موجود', 404)
        except (ValueError, json.JSONDecodeError) as exc:
            return self.err(str(exc), 400)
        except Exception as exc:
            log('ERROR', repr(exc))
            return self.err('حدث خطأ: ' + str(exc), 500)


def idle_watch():
    while True:
        time.sleep(20)
        try:
            check_idle()
        except Exception:
            pass


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    url = 'http://127.0.0.1:%d' % PORT
    try:
        server = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError:
        log('  The program is already running — opening it in the browser.')
        if not os.getenv('MAKTABI_NO_BROWSER'):
            import webbrowser
            webbrowser.open(url)
        return
    threading.Thread(target=cache_fonts, daemon=True).start()
    threading.Thread(target=idle_watch, daemon=True).start()
    line = '-' * 58
    log(line)
    log('  MAKTABI - personal prosecutor board  v' + APP_VERSION)
    log(line)
    log('  Open:  ' + (('https://' + EXTRA_HOSTS[0]) if SERVER_MODE else url + '   (this computer only)'))
    log('  Data:  ' + str(DATA_DIR) + '   (encrypted)')
    log('  PDF :  ' + (find_browser() or 'NOT FOUND - install Microsoft Edge or Chrome'))
    log('  Keep this window open while you work. Close it (or press STOP in the app) before removing the flash.')
    log(line)
    if not os.getenv('MAKTABI_NO_BROWSER'):
        import webbrowser
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=.25)
    except KeyboardInterrupt:
        pass
    finally:
        lock_now()
        server.server_close()
        log('  Stopped. Data is saved and locked.')


if __name__ == '__main__':
    main()
